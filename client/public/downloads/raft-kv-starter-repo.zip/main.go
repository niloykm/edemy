package main

import "fmt"

func main() {
	fmt.Println("Starting Raft Node...")
}
