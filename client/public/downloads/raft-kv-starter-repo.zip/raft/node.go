package raft

type NodeState int

const (
	Follower NodeState = iota
	Candidate
	Leader
)

type RaftNode struct {
	State NodeState
	CurrentTerm int
	VotedFor int
	Log []byte
}
