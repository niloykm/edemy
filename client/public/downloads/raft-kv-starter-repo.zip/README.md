# Raft Key-Value Store Starter Kit

Provided by Ndemy Distributed Systems Academy.
Run  or  to execute consensus verification tests.